﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace TiendaOnline.Pages;

public class PrivacyModel : PageModel
{
    public void OnGet()
    {
    }
}

