
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Data.SqlClient;

namespace TiendaOnline.Pages
{
    public class ConsultaModel : PageModel
    {
        private readonly IConfiguration _config;

        public ConsultaModel(IConfiguration config)
        {
            _config = config;
        }

        public List<Producto> Productos { get; set; } = new();

        public void OnGet()
        {
            string conexionString =
                _config.GetConnectionString("TiendaOnline")!;

            using (SqlConnection conexion =
                new SqlConnection(conexionString))
            {
                conexion.Open();

                string sql = @"SELECT
                                   p.idProducto,
                                   p.nombre,
                                   p.precio,
                                   c.descripcion AS categoria
                               FROM productos AS p
                               JOIN categorias AS c
                                   ON c.idCategoria = p.idCategoria
                               ORDER BY p.idProducto";

                using (SqlCommand comando =
                    new SqlCommand(sql, conexion))
                using (SqlDataReader registros =
                    comando.ExecuteReader())
                {
                    while (registros.Read())
                    {
                        Productos.Add(new Producto
                        {
                            IdProducto = Convert.ToInt32(
                                registros["idProducto"]),

                            Nombre = registros["nombre"].ToString()!,

                            Precio = Convert.ToDecimal(
                                registros["precio"]),

                            Categoria = registros["categoria"].ToString()!
                        });
                    }
                }
            }
        }

        public class Producto
        {
            public int IdProducto { get; set; }
            public string Nombre { get; set; } = string.Empty;
            public decimal Precio { get; set; }
            public string Categoria { get; set; } = string.Empty;
        }
    }
}
