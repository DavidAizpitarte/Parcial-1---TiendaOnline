
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.Data.SqlClient;

namespace TiendaOnline.Pages
{
    public class ModificacionModel : PageModel
    {
        private readonly IConfiguration _config;

        public ModificacionModel(IConfiguration config)
        {
            _config = config;
        }

        [BindProperty]
        public int IdProducto { get; set; }

        [BindProperty]
        public string Nombre { get; set; } = string.Empty;

        [BindProperty]
        public decimal Precio { get; set; }

        [BindProperty]
        public int IdCategoria { get; set; }

        [BindProperty]
        public bool ProductoEncontrado { get; set; }

        public List<SelectListItem> Categorias { get; set; } = new();

        public string Mensaje { get; set; } = string.Empty;

        public void OnGet()
        {
            CargarCategorias();
        }

        private void CargarCategorias()
        {
            Categorias.Clear();

            string conexionString =
                _config.GetConnectionString("TiendaOnline")!;

            using (SqlConnection conexion =
                new SqlConnection(conexionString))
            {
                conexion.Open();

                string sql =
                    "SELECT idCategoria, descripcion FROM categorias ORDER BY descripcion";

                using (SqlCommand comando =
                    new SqlCommand(sql, conexion))
                using (SqlDataReader registros =
                    comando.ExecuteReader())
                {
                    while (registros.Read())
                    {
                        Categorias.Add(new SelectListItem(
                            registros["descripcion"].ToString()!,
                            registros["idCategoria"].ToString()!
                        ));
                    }
                }
            }
        }

        public IActionResult OnPostBuscar()
        {
            CargarCategorias();

            if (IdProducto <= 0)
            {
                Mensaje = "Ingresá un ID de producto válido.";
                ModelState.Clear();
                return Page();
            }

            string conexionString =
                _config.GetConnectionString("TiendaOnline")!;

            using (SqlConnection conexion =
                new SqlConnection(conexionString))
            {
                conexion.Open();

                string sql = @"SELECT nombre, precio, idCategoria
                               FROM productos
                               WHERE idProducto = @idProducto";

                using (SqlCommand comando =
                    new SqlCommand(sql, conexion))
                {
                    comando.Parameters.AddWithValue(
                        "@idProducto", IdProducto);

                    using (SqlDataReader registro =
                        comando.ExecuteReader())
                    {
                        if (registro.Read())
                        {
                            Nombre = registro["nombre"].ToString()!;
                            Precio = Convert.ToDecimal(registro["precio"]);
                            IdCategoria = Convert.ToInt32(
                                registro["idCategoria"]);

                            ProductoEncontrado = true;
                            Mensaje = "Producto encontrado.";
                        }
                        else
                        {
                            ProductoEncontrado = false;
                            Mensaje = "No existe un producto con ese ID.";
                        }
                    }
                }
            }

            ModelState.Clear();
            return Page();
        }

        public IActionResult OnPostGuardar()
        {
            CargarCategorias();

            if (IdProducto <= 0)
            {
                Mensaje = "El ID del producto no es válido.";
                ModelState.Clear();
                return Page();
            }

            if (string.IsNullOrWhiteSpace(Nombre))
            {
                ProductoEncontrado = true;
                Mensaje = "El nombre del producto es obligatorio.";
                ModelState.Clear();
                return Page();
            }

            if (Precio <= 0)
            {
                ProductoEncontrado = true;
                Mensaje = "El precio debe ser mayor que cero.";
                ModelState.Clear();
                return Page();
            }

            string conexionString =
                _config.GetConnectionString("TiendaOnline")!;

            using (SqlConnection conexion =
                new SqlConnection(conexionString))
            {
                conexion.Open();

                string sqlActual = @"SELECT nombre, precio, idCategoria
                                     FROM productos
                                     WHERE idProducto = @idProducto";

                string nombreActual;
                decimal precioActual;
                int categoriaActual;

                using (SqlCommand comando =
                    new SqlCommand(sqlActual, conexion))
                {
                    comando.Parameters.AddWithValue(
                        "@idProducto", IdProducto);

                    using (SqlDataReader registro =
                        comando.ExecuteReader())
                    {
                        if (!registro.Read())
                        {
                            ProductoEncontrado = false;
                            Mensaje = "El producto ya no existe.";
                            ModelState.Clear();
                            return Page();
                        }

                        nombreActual = registro["nombre"].ToString()!;
                        precioActual = Convert.ToDecimal(
                            registro["precio"]);
                        categoriaActual = Convert.ToInt32(
                            registro["idCategoria"]);
                    }
                }

                bool huboCambios =
                    nombreActual != Nombre.Trim() ||
                    precioActual != Precio ||
                    categoriaActual != IdCategoria;

                if (!huboCambios)
                {
                    ProductoEncontrado = true;
                    Mensaje = "No modificaste ningún campo. Cambiá al menos un dato antes de guardar.";
                    ModelState.Clear();
                    return Page();
                }

                string sqlActualizar = @"UPDATE productos
                                          SET nombre = @nombre,
                                              precio = @precio,
                                              idCategoria = @idCategoria
                                          WHERE idProducto = @idProducto";

                using (SqlCommand comando =
                    new SqlCommand(sqlActualizar, conexion))
                {
                    comando.Parameters.AddWithValue(
                        "@nombre", Nombre.Trim());

                    comando.Parameters.AddWithValue(
                        "@precio", (double)Precio);

                    comando.Parameters.AddWithValue(
                        "@idCategoria", IdCategoria);

                    comando.Parameters.AddWithValue(
                        "@idProducto", IdProducto);

                    comando.ExecuteNonQuery();
                }
            }

            ProductoEncontrado = true;
            Mensaje = "¡Producto modificado correctamente!";

            ModelState.Clear();
            return Page();
        }
    }
}
