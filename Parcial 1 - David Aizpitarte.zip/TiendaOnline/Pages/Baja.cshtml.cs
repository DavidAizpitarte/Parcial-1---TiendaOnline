
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Data.SqlClient;

namespace TiendaOnline.Pages
{
    public class BajaModel : PageModel
    {
        private readonly IConfiguration _config;

        public BajaModel(IConfiguration config)
        {
            _config = config;
        }

        [BindProperty]
        public int IdProducto { get; set; }

        public string Nombre { get; set; } = string.Empty;

        public decimal Precio { get; set; }

        public string Categoria { get; set; } = string.Empty;

        public bool ProductoEncontrado { get; set; }

        public string Mensaje { get; set; } = string.Empty;

        public void OnGet()
        {
        }

        public IActionResult OnPostBuscar()
        {
            if (IdProducto <= 0)
            {
                Mensaje = "Ingresá un ID de producto válido.";
                ModelState.Clear();
                return Page();
            }

            string conexionString =
                _config.GetConnectionString("TiendaOnline")!;

            using (SqlConnection conexion =
                new SqlConnection(conexionString))
            {
                conexion.Open();

                string sql = @"SELECT
                                   p.nombre,
                                   p.precio,
                                   c.descripcion AS categoria
                               FROM productos AS p
                               JOIN categorias AS c
                                   ON c.idCategoria = p.idCategoria
                               WHERE p.idProducto = @idProducto";

                using (SqlCommand comando =
                    new SqlCommand(sql, conexion))
                {
                    comando.Parameters.AddWithValue(
                        "@idProducto", IdProducto);

                    using (SqlDataReader registro =
                        comando.ExecuteReader())
                    {
                        if (registro.Read())
                        {
                            Nombre = registro["nombre"].ToString()!;
                            Precio = Convert.ToDecimal(
                                registro["precio"]);
                            Categoria = registro["categoria"].ToString()!;

                            ProductoEncontrado = true;
                            Mensaje = "Producto encontrado. Revisá los datos antes de eliminarlo.";
                        }
                        else
                        {
                            Mensaje = "No existe un producto con ese ID.";
                        }
                    }
                }
            }

            ModelState.Clear();
            return Page();
        }

        public IActionResult OnPostEliminar()
        {
            if (IdProducto <= 0)
            {
                Mensaje = "El ID del producto no es válido.";
                ModelState.Clear();
                return Page();
            }

            string conexionString =
                _config.GetConnectionString("TiendaOnline")!;

            using (SqlConnection conexion =
                new SqlConnection(conexionString))
            {
                conexion.Open();

                string sql = @"DELETE FROM productos
                               WHERE idProducto = @idProducto";

                using (SqlCommand comando =
                    new SqlCommand(sql, conexion))
                {
                    comando.Parameters.AddWithValue(
                        "@idProducto", IdProducto);

                    int cantidad = comando.ExecuteNonQuery();

                    if (cantidad > 0)
                    {
                        Mensaje = "¡Producto eliminado correctamente!";
                    }
                    else
                    {
                        Mensaje = "El producto no existe o ya fue eliminado.";
                    }
                }
            }

            IdProducto = 0;
            ModelState.Clear();

            return Page();
        }
    }
}
