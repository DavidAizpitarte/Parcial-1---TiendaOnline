
using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.Data.SqlClient;

namespace TiendaOnline.Pages
{
    public class AltaModel : PageModel
    {
        private readonly IConfiguration _config;

        public AltaModel(IConfiguration config)
        {
            _config = config;
        }

        [BindProperty]
        [Required(ErrorMessage = "Ingresá el nombre del producto.")]
        public string Nombre { get; set; } = string.Empty;

        [BindProperty]
        [Range(0.01, 1000000000, ErrorMessage = "El precio debe ser mayor que cero.")]
        public decimal Precio { get; set; }

        [BindProperty]
        [Range(1, int.MaxValue, ErrorMessage = "Seleccioná una categoría.")]
        public int IdCategoria { get; set; }

        public List<SelectListItem> Categorias { get; set; } = new();

        public string Mensaje { get; set; } = string.Empty;

        public void OnGet()
        {
            CargarCategorias();
        }

        public void CargarCategorias()
        {
            Categorias.Clear();

            string conexionString =
                _config.GetConnectionString("TiendaOnline")!;

            using (SqlConnection conexion =
                new SqlConnection(conexionString))
            {
                conexion.Open();

                string sql =
                    "SELECT idCategoria, descripcion FROM categorias ORDER BY descripcion";

                using (SqlCommand comando =
                    new SqlCommand(sql, conexion))
                using (SqlDataReader registros =
                    comando.ExecuteReader())
                {
                    while (registros.Read())
                    {
                        Categorias.Add(new SelectListItem(
                            registros["descripcion"].ToString()!,
                            registros["idCategoria"].ToString()!
                        ));
                    }
                }
            }
        }

        public IActionResult OnPost()
        {
            CargarCategorias();

            if (!ModelState.IsValid)
            {
                return Page();
            }

            string conexionString =
                _config.GetConnectionString("TiendaOnline")!;

            using (SqlConnection conexion =
                new SqlConnection(conexionString))
            {
                conexion.Open();

                string sql = @"INSERT INTO productos
                               (nombre, precio, idCategoria)
                               VALUES
                               (@nombre, @precio, @idCategoria)";

                using (SqlCommand comando =
                    new SqlCommand(sql, conexion))
                {
                    comando.Parameters.AddWithValue("@nombre", Nombre.Trim());
                    comando.Parameters.AddWithValue("@precio", (double)Precio);
                    comando.Parameters.AddWithValue("@idCategoria", IdCategoria);

                    comando.ExecuteNonQuery();
                }
            }

            Nombre = string.Empty;
            Precio = 0;
            IdCategoria = 0;

            ModelState.Clear();

            Mensaje = "¡Producto cargado correctamente!";

            return Page();
        }
    }
}
