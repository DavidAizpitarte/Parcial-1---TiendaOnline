using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace TiendaOnline.Pages;

public class IndexModel : PageModel
{
    public void OnGet()
    {

    }
}
