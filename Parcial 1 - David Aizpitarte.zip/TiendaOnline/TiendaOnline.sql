/*
    TiendaOnline - Script de creacion de base de datos
    Motor: SQL Server Express

    Este script crea la base de datos TiendaOnline, sus tablas,
    la relacion entre productos y categorias y cinco productos
    de ejemplo para probar la aplicacion.
    
*/

CREATE DATABASE TiendaOnline;
GO

USE TiendaOnline;
GO

CREATE TABLE categorias (
    idCategoria INT IDENTITY PRIMARY KEY,
    descripcion VARCHAR(50)
);
GO

CREATE TABLE productos (
    idProducto INT IDENTITY PRIMARY KEY,
    nombre VARCHAR(100),
    precio FLOAT,
    idCategoria INT,
    FOREIGN KEY (idCategoria) REFERENCES categorias(idCategoria)
);
GO

INSERT INTO categorias (descripcion) VALUES ('Tablas de Skate');
INSERT INTO categorias (descripcion) VALUES ('Ropa');
INSERT INTO categorias (descripcion) VALUES ('Zapatillas');
INSERT INTO categorias (descripcion) VALUES ('Accesorios');
INSERT INTO categorias (descripcion) VALUES ('Protecciones');
GO

INSERT INTO productos (nombre, precio, idCategoria)
VALUES ('Tabla Skate Element', 120000, 1);

INSERT INTO productos (nombre, precio, idCategoria)
VALUES ('Remera SouthForce', 35000, 2);

INSERT INTO productos (nombre, precio, idCategoria)
VALUES ('Zapatillas Vans Old Skool', 95000, 3);

INSERT INTO productos (nombre, precio, idCategoria)
VALUES ('Mochila Skate', 45000, 4);

INSERT INTO productos (nombre, precio, idCategoria)
VALUES ('Casco para Skate', 55000, 5);
GO

-- Consulta de prueba: muestra productos junto con sus categorias.
SELECT
    p.idProducto,
    p.nombre,
    p.precio,
    c.descripcion AS categoria
FROM productos AS p
JOIN categorias AS c
    ON c.idCategoria = p.idCategoria;
GO
